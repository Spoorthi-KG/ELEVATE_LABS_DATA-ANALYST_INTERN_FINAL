# HR Analytics – Predict Employee Attrition

## Overview
This repository contains an end-to-end HR Analytics project to predict employee attrition using Logistic Regression and Random Forest. It includes EDA, model training, explainability outputs, and a GitHub-style summary report.

## Files
- `data/HR-Employee-Attrition.csv` - dataset used
- `notebooks/HR_Attrition_Analysis.ipynb` - Jupyter notebook (exported separately)
- `outputs/attrition_predictions.csv` - predictions with probabilities
- `outputs/rf_attrition_model.joblib` - Random Forest model
- `outputs/lr_attrition_model.joblib` - Logistic Regression model
- `outputs/feature_importance.png` - top 10 feature importances
- `outputs/shap_summary_plot.png` - SHAP summary plot or placeholder
- `report/HR_Attrition_Report.pdf` - GitHub-style one-page PDF summary

## Quick Results
- Logistic Regression ROC AUC: 0.799
- Random Forest ROC AUC: 0.768

## How to run
1. Create a virtual environment
2. Install dependencies: `pip install -r requirements.txt`
3. Open the notebook in `notebooks/HR_Attrition_Analysis.ipynb` and run cells.
